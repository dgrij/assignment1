#include <iostream>     // for cout and cin
//#include "LineKeeper.h"   // for LineKeeper class
#include "Line.h"
//#include "string.h"
#include "linekeeper.h"
using namespace std;   // safe to use this using-directive here

int main()
{
   
	{
	
	LineKeeper lk ("originalterroristtext.txt");

	

	lk.print(5,-25);

	lk.print(1,5);

	lk.print(-23,-25);

	lk.print(2,25);

	
	}




		


		/*
	Line line ("This is a l");
	line.print();
	line.empty();
	line.capacity();

	Line huevito("Huevito");

	huevito.print();
	huevito.capacity();

	for (int i=0; i <1000; i++){
	huevito.push_back('a');
	}
	huevito.print();
	huevito.capacity();
	

	for (int i=0; i <1500; i++){
	huevito.pop_back();
	}
	huevito.print();
	huevito.capacity();
	


	for (int i=0; i <1000; i++){
	huevito.push_back('a');
	}
	huevito.print();
	huevito.capacity();
	



	Line otroHuevito;
	otroHuevito=huevito;

	otroHuevito.print();


	//Line charLine('a');
	//charLine.print();
	//charLine.resize();
	//charLine.capacity();

	Line cinLine("Gleb");

	cinLine.print();

	cin>>cinLine;

	cinLine.print();
	
	*/

	



	while (true){	}
	
	
	
	
		
	/*
	
	LineKeeper m1; // an empty string
    cout << "m1:" << m1 << endl;

    LineKeeper m2("too many friends spoil information hiding!");
    cout << "m2:" << m2 << endl;

    {
        LineKeeper m2("I'm different from the m2 object above, " // note how we split
            "and just about to die, bye!"); // C-strings across lines
        cout << "m:" << m2 << endl;
    }

    LineKeeper m3{ m2 }; // copy ctor, C++11
    cout << "m3:" << m3 << endl;

    LineKeeper m4(m3);   // copy ctor
    cout << "m4:" << m4 << endl;

    LineKeeper m5 = m4;  // copy ctor
    cout << "m5:" << m5 << endl;

    m1 = m3;         // copy assignment overload
    cout << "m1:" << m1 << endl;

    pm->print();
    //  (*pm).print();   // same as above
    delete pm;
    pm = nullptr;  // defensive programming

	*/

    //return 0;   // same as return EXIT_SUCCESS; from <cstdlib>

	
}
