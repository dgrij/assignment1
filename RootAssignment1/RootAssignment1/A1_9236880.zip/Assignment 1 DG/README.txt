Linked List implemented generically in header file only. Therefore LinkedList.cpp does not exist.

List Node is a nested class of Linked List.

Input file name: text.txt

Output taken from console with example from assignment requirements.

Dmitri Grijalva 9236880



